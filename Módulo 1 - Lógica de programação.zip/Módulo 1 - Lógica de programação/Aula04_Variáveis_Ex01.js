nomeCompleto = ("Andreza Araújo Duarte")
apelido = ("Dedê")
idade = 25
dataNascimento = ("05/09/1995")
localNascimento = ("Campina Grande/PB")
altura = 1.67
trabalhando = false

apresentacao = "Meu nome é " + nomeCompleto + " (sou conhecida como " + apelido + ") e tenho " + idade + " anos. Nasci no dia " + dataNascimento + ", na cidade de " + localNascimento + ". Tenho " + altura + "m de altura e atualmente estou " + (trabalhando ? "empregada" : "desempregada") + "."